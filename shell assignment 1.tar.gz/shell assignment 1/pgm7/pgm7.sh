#!/bin/bash
#usage:files with only read and write permissions

echo "files with only read and write permissions"
#ls +r+w-l
#find / -perm /u+w,g+w,o+w 
ls -l 
#find / -perm /+r,+w
#find / -user sois -perm 777
#find . -user $(whoami) -perm 777
 find /home/sois/   -perm u+rw
