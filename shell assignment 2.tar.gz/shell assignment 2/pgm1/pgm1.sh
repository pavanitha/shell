#Implement a shell script to print the depth of the directory the cursor is present


find . -mindepth 1 -type d | wc -l

