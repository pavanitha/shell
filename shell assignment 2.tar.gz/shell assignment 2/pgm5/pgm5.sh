echo "Enter the option"
echo "1 to find pdf"
echo "2 to find image in jpg"
read option

case "$option" in
	"1") find -iname '*.pdf'
	;;
	"2") find -iname '*.png|'
	;;
esac
